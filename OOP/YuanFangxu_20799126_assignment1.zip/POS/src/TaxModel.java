

public interface TaxModel {
	public float afterTaxPrice(float price);
}

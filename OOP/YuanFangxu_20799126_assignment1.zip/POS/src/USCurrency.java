

public class USCurrency extends Currency{
	public String show() {
		return "US$";
	}
}

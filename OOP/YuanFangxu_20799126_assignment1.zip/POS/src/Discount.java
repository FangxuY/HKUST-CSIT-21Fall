

public interface Discount {
	public float discount();
	public String discountMessage();
}

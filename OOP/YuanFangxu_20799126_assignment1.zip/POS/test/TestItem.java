import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;




public class TestItem {
	private String itemName;
	private Integer number;
	private Float price;
	private ProductDiscount discount1;
	private Item item;
	
    @BeforeEach
    public void setUp() throws Exception {
    	discount1 = new ProductDiscount(0.2f);
    	itemName = "HKUST";
    	number = 2;
    	price = 0.8f;
    	item = new Item(itemName, number,price);
    }

    @AfterEach
    public void tearDown() throws Exception {
        item = null;
    }
    
    @Test
    public void testItem() {
    	assertNotNull(item);
    }
    @Test
    public void testsetDiscount() {
    	item.setDiscount(discount1);
    	assertTrue(item.discount.discount() == 0.2f);
    }
}

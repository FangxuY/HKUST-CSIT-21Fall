import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestPayment {

    private Payment payment;
    private ProductDiscount discount1;
    private EventDiscount discount2;
    private CustomerDiscount discount3;
    private double sum;
    
    @BeforeEach
    public void setUp() throws Exception {
        payment = new Payment();
        discount1 = new ProductDiscount(0.1f);
        discount2 = new EventDiscount(0.1f);
        discount3 = new CustomerDiscount(0.05f);
    }

    @AfterEach
    public void tearDown() throws Exception {
        payment = null;
        discount1 = null;
        discount2 = null;
        discount3 = null;
    }
    @Test
    public void testaddDiscount() {
        //initially, there is no discount   
        assertTrue(payment.totalDiscount.discount() == 1.0f);

        //add first discount, the total discount will be 0.9
        payment.addDiscount(discount1);
        assertTrue(payment.totalDiscount.discount() == 0.9f);
		
        //add second discount, the total discount will be 0.9 * 0.9
        payment.addDiscount(discount2);
        assertTrue(payment.totalDiscount.discount() == 0.9f * 0.9f);
        
        payment.addDiscount(discount3);
        assertTrue(payment.totalDiscount.discount() == 0.9f * 0.9f * 0.95f);
    	sum = 1000;
        assertTrue(payment.afterDiscount(sum) == 769.4999575614929);
        System.out.println(payment.showDiscount());
    }

    


}

import java.util.Scanner;
import java.util.*;
import java.io.*;
import java.math.BigDecimal;
import java.math.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;



public class TestPOS {
	POS pos;
	private CurrencyFactory.Country country_1;
	private String batchFile;
	private BufferedReader baReader;
	private String salesRecordFile = "logAndSales.txt";


    @BeforeEach
    public void setUp() throws Exception {
        pos= new POS();
        country_1 = CurrencyFactory.Country.HK;
        batchFile = "";
    }
	
	@Test
	public void testtest() {
		assertTrue(pos.test() == 1);
	}
	
	@Test
	public void testgetInst() {
		assertNotNull(pos.getInst());
		pos.getInst();
		assertNotNull(pos.getInst());
	}
	
	@Test
	public void testgetTaxModel() {
		String s = "NOTAX";
		String s1 = "VAT";
		assertNull(pos.taxModel);
		pos.getTaxModel(s);
		assertNotNull(pos.taxModel);
		pos.getTaxModel(s1);
		assertNotNull(pos.taxModel);
	}
	
	@Test
	public void testsetCurrency() {
		pos.setCurrency(null);
		assertFalse(pos.setCurrency(null));
		pos.setCurrency(country_1);
		assertTrue(pos.setCurrency(country_1));
	}
	
	@Test
	public void testcheckCurrency() {
		String s = "HK";
		pos.checkCurrency(s);
		assertTrue(pos.setCurrency(CurrencyFactory.Country.HK));
		String s1 = "US";
		pos.checkCurrency(s1);
		assertTrue(pos.setCurrency(CurrencyFactory.Country.US));
	}
	
	@Test
	public void testround() {
		double value = 100.345678;
		int scale = 4;
		int roundingMode = 0;
		double res = pos.round(value, scale, roundingMode);
		assertTrue(res == 100.3457);
		
	}
	
	@Test
	public void testint2Str() {
		int i = 0;
		String s = pos.int2Str(i);
//		System.out.println(s);
		assertTrue(s.equals("00"));
	}
	
	@Test
	public void testgetline() {
        Exception exception = assertThrows(NullPointerException.class, () ->
        pos.getLine());

	}
	
	@Test
	public void testgetNum() {
		String sMode = "0";
		pos.batchMode = false;
		int res = pos.getNum(sMode);
		ByteArrayInputStream strIn=new ByteArrayInputStream(sMode.getBytes());
		System.setIn(strIn);
		System.out.println(res);
		assertEquals(res, 0);
	}
	
	@Test
	public void testgetNum1() {
		String sMode = "-1";
		pos.batchMode = false;
		String s = "0";
		System.setIn(new ByteArrayInputStream(s.getBytes()));
		int res = pos.getNum(sMode);

		System.out.println(res);
		assertEquals(res, 0);
	}

	@Test
	public void testgetNum2() {
		String sMode = "1.0";
		pos.batchMode = false;
		String s = "1";
		System.setIn(new ByteArrayInputStream(s.getBytes()));
		int res = pos.getNum(sMode);

		System.out.println(res);
		assertEquals(res, 1);
	}

	@Test
	public void testgetFloat() {
		String sMode = "0.0";
		pos.batchMode = false;
//		System.out.println(res);
		ByteArrayInputStream strIn=new ByteArrayInputStream(sMode.getBytes());
		System.setIn(strIn);
		float res = pos.getFloat(sMode);
		assertEquals(res, 0.0);
	}
	@Test
	public void testgetFloat1() {
		pos.batchMode = false;
		String sMode = "-1.0";
		String s = "0.0";
		System.setIn(new ByteArrayInputStream(s.getBytes()));
		float res = pos.getFloat(sMode);
		assertEquals(res, 0.0);
	}
	
	@Test
	public void testgetFloat2() {
		pos.batchMode = false;
		String sMode = "k";
		String s = "1.0";
		System.setIn(new ByteArrayInputStream(s.getBytes()));
		float res = pos.getFloat(sMode);
		System.out.println(res);
		assertEquals(res, 1.0);
	}
	
	@Test
	public void testmain() {
		pos.batchMode = true;
		String[] str = {"batchfile1.txt"};
		
		String s = "y\n";
		System.setIn(new ByteArrayInputStream(s.getBytes()));
        pos.main(str);
	}


}

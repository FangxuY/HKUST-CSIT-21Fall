import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestCompositeDiscount {
    private CompositeDiscount compDiscount;
    private ProductDiscount discount1;
    private ProductDiscount discount2;

    @BeforeEach
    public void setUp() throws Exception {
        compDiscount = new CompositeDiscount();
        discount1 = new ProductDiscount(0.2f);
        discount2 = new ProductDiscount(0.05f);
    }

    @AfterEach
    public void tearDown() throws Exception {
        compDiscount = null;
        discount1 = null;
        discount2 = null;
    }

    @Test
    public void testAddDiscount() {
        //initially, there is no discount   
        assertTrue(compDiscount.discount() == 1.0f);

        //add first discount, the total discount will be 0.8
        compDiscount.add(discount1);
        assertTrue(compDiscount.discount() == 0.8f);
		
        //add second discount, the total discount will be 0.8 * 0.95
        compDiscount.add(discount2);
        assertTrue(compDiscount.discount() == 0.8f * 0.95f);


    	assertTrue(compDiscount.discountMessage().equals("\tProduct Discount: \tProduct Discount: "));
    }
    
    @Test
    public void testRemoveDiscount() {
        //after removing two discounts, there will be no discount
        compDiscount.remove(discount1);
        compDiscount.remove(discount2);
        assertTrue(compDiscount.discount() == 1.0f, "no savings after removing all discounts");
    }
    
}


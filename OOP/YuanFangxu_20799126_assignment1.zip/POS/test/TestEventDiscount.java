import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestEventDiscount {
	private EventDiscount eveDiscount;
    @BeforeEach
    public void setUp() throws Exception {
        eveDiscount = new EventDiscount(0.8f);
    }

    @AfterEach
    public void tearDown() throws Exception {
        eveDiscount = null;

    }
    
    @Test
    public void testdiscount() { 
        assertTrue(eveDiscount.discount() == 0.8f);
    }
    
    @Test
    public void testdiscountMessage() { 
    	System.out.println(eveDiscount.discountMessage());
        assertTrue(eveDiscount.discountMessage().equals("\tEvent Discount: 80.0%" + "\n"));
    }
}

import java.util.Scanner;

import java.util.*;
import java.io.*;
import java.math.BigDecimal;
import java.math.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class TestMain {
	POS pos;

	@BeforeEach
    public void setUp() throws Exception {

    }
    @AfterEach
    public void tearDown() throws Exception {

    }

	// Buy Nothing with membership
	@Test
	public void TestBuyNothing() { 
		//chunlin login
		POS pos = POS.getInst();
		POS.batchMode = false;

		pos.userPasswordFile = "userPasswordFile.txt";
		pos.itemListFile = "productlistFile.txt";
		pos.init();
		
		String s = "1\ny\nc\n1\n2\n";
		
		System.setIn(new ByteArrayInputStream(s.getBytes()));
		pos.saleRegister();

	}
	
	// Buy Nothing without membership
	@Test
	public void TestBuyNothing1() { 
		//chunlin login
		POS pos = POS.getInst();
		POS.batchMode = false;

		pos.userPasswordFile = "userPasswordFile.txt";
		pos.itemListFile = "productlistFile.txt";
		pos.init();
		
		String s = "1\nn\nc\n1\n2\n";
		
		System.setIn(new ByteArrayInputStream(s.getBytes()));
		pos.saleRegister();

	}
	
	// Buy nothing with membership in BatchMode.
	@Test
	public void TestBatchMode() { 
		//chunlin login
		POS pos = POS.getInst();
		POS.batchMode = true;
		POS.batchFile = "Batchfile.txt";
		pos.userPasswordFile = "userPasswordFile.txt";
		pos.itemListFile = "productlistFile.txt";
		pos.loadBatchFile();
		pos.init();
		
		String s = "y\n";
		System.setIn(new ByteArrayInputStream(s.getBytes()));
		pos.register();

	}
	
	// Buy ID001 and pay with membership in BatchMode.	
	@Test
	public void TestBatchMode1() { 
		//chunlin login
		POS pos = POS.getInst();
		POS.batchMode = true;
		POS.batchFile = "batchfile1.txt";
		pos.userPasswordFile = "userPasswordFile1.txt";
		pos.itemListFile = "productlistFile.txt";
		pos.loadBatchFile();
		pos.init();
		
		String s = "y\n";
		System.setIn(new ByteArrayInputStream(s.getBytes()));
		pos.register();
	}
	
	// Buy ID002 and pay with membership in BatchMode.
	@Test
	public void TestBatchMode2() { 
		//chunlin login
		POS pos = POS.getInst();
		POS.batchMode = true;
		POS.batchFile = "batchfile2.txt";
		pos.userPasswordFile = "userPasswordFile.txt";
		pos.itemListFile = "productlistFile.txt";
		pos.loadBatchFile();
		pos.init();
		
		String s = "y\n";
		System.setIn(new ByteArrayInputStream(s.getBytes()));
		pos.register();
		
	}
	
	// Test the wrong Username in command-line mode
	@Test
	public void TestWrongUsername() { 
		//chunlin login
		POS pos = POS.getInst();
		POS.batchMode = false;

		pos.userPasswordFile = "userPasswordFile.txt";
		pos.itemListFile = "productlistFile.txt";
		pos.init();
		
		String s = "fangxu\nchunlin\nchunlin\n\n";
		
		System.setIn(new ByteArrayInputStream(s.getBytes()));
	    Exception exception = assertThrows(NoSuchElementException.class, () -> {
	    	pos.register();
	       });
	}
	
	// Test the wrong Password in command-line mode
	@Test
	public void TestWrongPassword() { 
		//chunlin login
		POS pos = POS.getInst();
		POS.batchMode = false;

		pos.userPasswordFile = "userPasswordFile.txt";
		pos.itemListFile = "productlistFile.txt";
		pos.init();
		
		String s = "chunlin\nfangxu\nchunlin\n\n";
		
		System.setIn(new ByteArrayInputStream(s.getBytes()));

	    Exception exception = assertThrows(NoSuchElementException.class, () -> {
	    	pos.register();
	       });
	}
	// Mock to input incorrect number 4(not 0 or 1) at the first step in command-line mode
	@Test
	public void TestInputIncorrectNumberStep1() { 
		//chunlin login
		POS pos = POS.getInst();
		POS.batchMode = false;
		pos.userPasswordFile = "userPasswordFile.txt";
		pos.itemListFile = "productlistFile.txt";
		pos.init();
			
		String s = "4\n1\n";
			
		System.setIn(new ByteArrayInputStream(s.getBytes()));

	    Exception exception = assertThrows(NoSuchElementException.class, () -> {
	    	pos.saleRegister();
	       });
	}
	
	// Buy something do not exist in the productlistfile.
	@Test
	public void TestBuySomethingNotExist() { 
		//chunlin login
		POS pos = POS.getInst();
		POS.batchMode = false;

		pos.userPasswordFile = "userPasswordFile.txt";
		pos.itemListFile = "productlistFile.txt";
		pos.init();
		
		String s = "1\ny\nID0032\n1\n2\n";
			
		System.setIn(new ByteArrayInputStream(s.getBytes()));

	    Exception exception = assertThrows(NoSuchElementException.class, () -> {
	    	pos.saleRegister();
	       });
	}
	
	// Mock to input incorrect number b(not y or n) at the second step in command-line mode
	@Test
	public void TestInputIncorrectNumberStep2() { 
		//chunlin login
		POS pos = POS.getInst();
		POS.batchMode = false;
		
		pos.userPasswordFile = "userPasswordFile.txt";
		pos.itemListFile = "productlistFile.txt";
		pos.init();
			
		String s = "1\nb\n1\n2\n";
			
		System.setIn(new ByteArrayInputStream(s.getBytes()));

	    Exception exception = assertThrows(NoSuchElementException.class, () -> {
	    	pos.saleRegister();
	       });
	}
	
	// Test customers don't pay enough to cover the bill price
	@Test
	public void TestPayNotEnoughMoney() { 
		//chunlin login
		POS pos = POS.getInst();
		POS.batchMode = false;

		pos.userPasswordFile = "userPasswordFile.txt";
		pos.itemListFile = "productlistFile.txt";
		pos.init();
			
		String s = "1\ny\nID001\n1\nc\n0.1\n0.8\n2\n";
			
		System.setIn(new ByteArrayInputStream(s.getBytes()));


	    pos.saleRegister();
	}
		
	// mock quit when pay the bill
	@Test
	public void TestQuitWhenPayBill() { 
		//chunlin login
		POS pos = POS.getInst();
		POS.batchMode = true;
		POS.batchFile = "batchfile6.txt";
		pos.userPasswordFile = "userPasswordFile.txt";
		pos.itemListFile = "productlistFile.txt";
		pos.loadBatchFile();
		pos.init();
			
		String s = "y\n";
		System.setIn(new ByteArrayInputStream(s.getBytes()));
		pos.register();
			
	}



}

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;



public class TestCurrencyFactory {
	CurrencyFactory coun;
    private CurrencyFactory.Country country_1;
    private CurrencyFactory.Country country_2;
    private CurrencyFactory.Country country_3;
    
    @BeforeEach
    public void setUp() throws Exception {
        country_1 = CurrencyFactory.Country.HK;
        country_2 = CurrencyFactory.Country.US;
        country_3 = null;
    }

    @AfterEach
    public void tearDown() throws Exception {
    	country_1 = null;
    	country_2 = null;
   
    }
    
    @Test
    public void testceateCurrency() {
    	CurrencyFactory.createCurrency(country_1);
    	assertTrue(CurrencyFactory.createCurrency(country_1).show() == "HK$");
    	CurrencyFactory.createCurrency(country_2);
    	assertTrue(CurrencyFactory.createCurrency(country_2).show() == "US$");
    	CurrencyFactory.createCurrency(country_3);
    	assertTrue(CurrencyFactory.createCurrency(country_3) == null);

      

    }
    
}

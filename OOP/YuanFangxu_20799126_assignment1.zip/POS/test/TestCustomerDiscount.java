import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestCustomerDiscount {
    private CustomerDiscount cusDiscount;
    @BeforeEach
    public void setUp() throws Exception {
        cusDiscount = new CustomerDiscount(0.8f);
        

    }

    @AfterEach
    public void tearDown() throws Exception {
        cusDiscount = null;

    }
    
    @Test
    public void testdiscount() { 
        assertTrue(cusDiscount.discount() == 0.8f);
    }
    
    @Test
    public void testdiscountMessage() { 
    	System.out.println(cusDiscount.discountMessage());
        assertTrue(cusDiscount.discountMessage().equals("\tMembership Discount: 80.0%" + "\n"));
    }
    
}

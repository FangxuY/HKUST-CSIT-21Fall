## Assignment 1

Student Name: Yuan Fangxu

Student ID: 20799126

Assignment #: 1

Student Email: fyuanad@connect.ust.hk

Course Name: CSIT5910 Machine Learning

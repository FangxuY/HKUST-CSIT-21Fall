import csv
import math
import json
from decimal import Decimal
from re import I
import random

with open('AllPOI.csv', newline='', encoding='utf-8-sig') as f:
    reader = csv.reader(f)
    data = list(reader)


# check if two rectangles overlap
def overlap(a, b):
    a_maxX = float(a[1])
    a_maxY = float(a[3])
    a_minX = float(a[0])
    a_minY = float(a[2])
    b_maxX = float(b[1])
    b_maxY = float(b[3])
    b_minX = float(b[0])
    b_minY = float(b[2])
    # print('a_maxX is ', a_maxX)
    # print('b_maxX is ', b_maxX)
    return a_maxX <= b_maxX and a_minX >= b_minX and a_maxY <= b_maxY and a_minY >= b_minY


def numberScaleUp(num):
    # scale up the number by 100000 times
    index = 0
    s = str(num)
    for i in range(0, len(s)):
        if s[i] == '.':
            index = i
            break
    num_str = s[:index] + s[index + 1:]
    num_str = num_str[:index + 5] + '.' + num_str[index + 5:]
    return fix(float(num_str))


def numberScaleDown(num):
    # scale down the number by 100000 times
    index = 0
    s = str(num)
    for i in range(0, len(s)):
        if s[i] == '.':
            index = i
            break
    num_str = s[:index] + s[index + 1:]
    num_str = num_str[:index - 5] + '.' + num_str[index - 5:]
    return fix(float(num_str))


class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Decimal):
            return str(o)
        return super(DecimalEncoder, self).default(o)


def preprocess(num):
    # times 100000
    num = num * 100000
    return fix(float(num))


def fix(num):
    return Decimal(str(num)).quantize(Decimal('0.0000000000000'))


def MBR(data):
    left = Decimal('inf')
    down = Decimal('inf')
    right = Decimal('-inf')
    top = Decimal('-inf')
    for i in range(0, len(data)):
        x = Decimal(data[i][0])
        y = Decimal(data[i][1])
        left = min(x, left)
        down = min(y, down)
        top = max(y, top)
        right = max(x, right)
    return [fix(left), fix(down), fix(right), fix(top)]


def position(point, n, left, down, right, top):
    # times 100000
    x = fix(Decimal(point[0]) * 100000)
    y = fix(Decimal(point[1]) * 100000)
    divide_num = Decimal(2.0)
    for i in range(0, n):
        sum_x = right + left
        sum_y = top + down
        if x <= sum_x / divide_num:
            right = sum_x / divide_num
        else:
            left = sum_x / divide_num
        if y <= sum_y / divide_num:
            top = sum_y / divide_num
        else:
            down = sum_y / divide_num
    dict = [left, down, right, top]
    return json.dumps(dict, cls=DecimalEncoder)


# return true if n is correct
def createIndex(n, left, down, right, top):
    factor = int(math.pow(2, n))
    unitX = (right - left) / factor
    unitY = (top - down) / factor
    ans_dict = {}
    # create a hash map (KEY: left, down, right, top, VALUE: an empty list )
    for i in range(0, factor):
        for j in range(0, factor):
            Left = left + i * unitX
            Down = down + j * unitY
            Right = left + (i + 1) * unitX
            Top = down + (j + 1) * unitY
            dict = [Left, Down, Right, Top]
            dict = json.dumps(dict, cls=DecimalEncoder)
            ans_dict[dict] = []
    for k in range(0, len(data)):
        pos = position(data[k], n, left, down, right, top)
        ans_dict[pos].append(data[k])

    for key in list(ans_dict.keys()):
        if not ans_dict.get(key):
            del ans_dict[key]
    return ans_dict


def numOfPointsUnderQuery(window, dict):
    ans = 0
    for key in dict:
        if overlap(json.loads(window), json.loads(key)):
            ans += len(dict[key])
    return ans


if __name__ == '__main__':
    my_list = MBR(data)
    left = preprocess(my_list[0])
    down = preprocess(my_list[1])
    right = preprocess(my_list[2])
    top = preprocess(my_list[3])
    index = 0

    print("Task 3(1) answer is: ")
    dict = createIndex(9, left, down, right, top)
    print(len(dict))

    window = ["11748473.1867187500000", "4064799.5136718750000", "11748874.3000000000000", "4065110.0664062500000"]
    window = json.dumps(window)
    pointsNum = numOfPointsUnderQuery(window, dict)
    print(pointsNum)

    print("Task 3(3) answer is: ")
    for i in range(0, 20):
        proxy1 = random.choice(list(dict))
        window = proxy1
        pointsNum = numOfPointsUnderQuery(window, dict)
        print("Batch", i, ": ", pointsNum)

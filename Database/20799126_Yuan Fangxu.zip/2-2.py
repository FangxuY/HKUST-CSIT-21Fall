import csv
import json
from collections import OrderedDict


with open('AllPOI.csv', newline='', encoding='utf-8-sig') as f:
    reader = csv.reader(f)
    data = list(reader)



def fix(num):
    return float(str(num))


def preprocess(num):
    # times 100000
    num_str = num * 100000
    return fix(float(num_str))


def MBR():
    left = float('inf')
    down = left
    right = float('-inf')
    top = right

    for i in range(0, len(data)):
        x = float(data[i][0])
        y = float(data[i][1])
        left = min(x, left)
        down = min(y, down)
        top = max(y, top)
        right = max(x, right)

    return [fix(left), fix(down), fix(right), fix(top)]


def helper(num, base):
    base_num = ""
    while num > 0:
        dig = int(num % base)
        if dig < 10:
            base_num += str(dig)
        else:
            base_num += chr(ord('A')+dig-10)
        num //= base

    base_num = base_num[::-1]
    return base_num


def get_z_value(point, n, left, down, right, top):
    # times 100000
    x = fix(float(point[0]) * 100000)
    y = fix(float(point[1]) * 100000)
    divide_num = float(2.0)
    Z_X = ""
    Z_Y = ""
    for i in range(0, n):
        sum_x = right + left
        sum_y = top + down
        if x <= sum_x / divide_num:
            Z_X += "0"
            right = sum_x / divide_num
        else:
            Z_X += "1"
            left = sum_x / divide_num
        if y <= sum_y / divide_num:
            Z_Y += "0"
            top = sum_y / divide_num
        else:
            Z_Y += "1"
            down = sum_y / divide_num
    Z_value = ""

    for i in range(0, len(Z_X) + len(Z_Y)):
        if i % 2 == 0:
            Z_value += Z_X[int(i / 2)]
        else:
            Z_value += Z_X[int((i - 1) / 2)]

    Z_value = int(Z_value, 2)
    Z_value = helper(Z_value, 5)

    return Z_value


def index_Z(n, left, down, right, top):
    Z_Value = {}
    for k in range(0, len(data)):
        z = get_z_value(data[k], n, left, down, right, top)
        Z_Value[str(data[k])] = z

    z_points = {}
    for key in Z_Value:
        z_points[Z_Value[key]] = []
    for key in Z_Value:
        z_points[Z_Value[key]].append(key)

    # sort the order dictionary by key
    z_points = OrderedDict(sorted(z_points.items()))
    # z_points = OrderedDict(sorted(Z_Value.items(), key = lambda kv:(kv[1], kv[0])))
    return z_points


if __name__ == '__main__':
    my_list = MBR()
    left = preprocess(my_list[0])
    down = preprocess(my_list[1])
    right = preprocess(my_list[2])
    top = preprocess(my_list[3])

    print("Task 2(2) answer is: ")
    dict = index_Z(9, left, down, right, top)
    # print(dict)
    # print(len(dict))
    for key in dict.keys():
        print("     Key: ", key, " Value: ", dict[key])

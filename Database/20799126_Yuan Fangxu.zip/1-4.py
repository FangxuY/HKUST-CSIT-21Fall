import csv
import math
import json
from decimal import Decimal
from re import I

with open('AllPOI.csv', newline='', encoding='utf-8-sig') as f:
    reader = csv.reader(f)
    data = list(reader)


class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Decimal):
            return str(o)
        return super(DecimalEncoder, self).default(o)


def preprocess(num):
    # times 100000
    num = num * 100000
    return fix(float(num))


def fix(num):
    return Decimal(str(num)).quantize(Decimal('0.0000000000000'))


def MBR(data):
    left = Decimal('inf')
    down = Decimal('inf')
    right = Decimal('-inf')
    top = Decimal('-inf')
    for i in range(0, len(data)):
        x = Decimal(data[i][0])
        y = Decimal(data[i][1])
        left = min(x, left)
        down = min(y, down)
        top = max(y, top)
        right = max(x, right)
    return [fix(left), fix(down), fix(right), fix(top)]


def position(point, n, left, down, right, top):
    # times 100000
    x = fix(Decimal(point[0]) * 100000)
    y = fix(Decimal(point[1]) * 100000)
    divide_num = Decimal(2.0)
    for i in range(0, n):
        sum_x = right + left
        sum_y = top + down
        if x <= sum_x / divide_num:
            right = sum_x / divide_num
        else:
            left = sum_x / divide_num
        if y <= sum_y / divide_num:
            top = sum_y / divide_num
        else:
            down = sum_y / divide_num
    dict = [left, down, right, top]
    return json.dumps(dict, cls=DecimalEncoder)


# return true if n is correct


def createIndex(n, left, down, right, top):
    factor = int(math.pow(2, n))
    unitX = (right - left) / factor
    unitY = (top - down) / factor
    ans_dict = {}
    # create a hash map (KEY: left, down, right, top, VALUE: an empty list )
    for i in range(0, factor):
        for j in range(0, factor):
            Left = left + i * unitX
            Down = down + j * unitY
            Right = left + (i + 1) * unitX
            Top = down + (j + 1) * unitY
            # dict = {'left': Left, 'down': Down, 'right': Right, 'top': Top}
            dict = [Left, Down, Right, Top]
            dict = json.dumps(dict, cls=DecimalEncoder)
            ans_dict[dict] = []
    for k in range(0, len(data)):
        pos = position(data[k], n, left, down, right, top)
        ans_dict[pos].append(data[k])
    for key in list(ans_dict.keys()):
        if not ans_dict.get(key):
            del ans_dict[key]
    return ans_dict


if __name__ == '__main__':
    my_list = MBR(data)
    left = preprocess(my_list[0])
    down = preprocess(my_list[1])
    right = preprocess(my_list[2])
    top = preprocess(my_list[3])
    index = 0

    print("Task 1(4) answer is: ")
    dict = createIndex(9, left, down, right, top)
    print(len(dict))
    for key in list(dict.keys()):
        print("     Key: ", key, " Value: ", dict[key])

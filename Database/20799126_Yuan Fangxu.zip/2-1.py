import csv
import math
import json
from re import I

with open('AllPOI.csv', newline='', encoding='utf-8-sig') as f:
    reader = csv.reader(f)
    data = list(reader)



def preprocess(num):
    # times 100000
    num = num * 100000
    return fix(float(num))


def fix(num):
    return float(str(num))


def MBR():
    left = float('inf')
    down = float('inf')
    right = float('-inf')
    top = float('-inf')
    for i in range(0, len(data)):
        x = float(data[i][0])
        y = float(data[i][1])
        left = min(x, left)
        down = min(y, down)
        top = max(y, top)
        right = max(x, right)
    return [fix(left), fix(down), fix(right), fix(top)]


def helper(num, base):
    base_num = ""
    while num > 0:
        k = int(num % base)
        if k < 10:
            base_num += str(k)
        else:
            base_num += chr(ord('A') + k - 10)
        num //= base

    base_num = base_num[::-1]
    return base_num


def get_z_value(point, n, left, down, right, top):
    # times 100000
    x = fix(float(point[0]) * 100000)
    y = fix(float(point[1]) * 100000)
    divide_num = float(2.0)
    Z_X = ""
    Z_Y = ""
    for i in range(0, n):
        sum_x = right + left
        sum_y = top + down
        if x <= sum_x / divide_num:
            Z_X += "0"
            right = sum_x / divide_num
        else:
            Z_X += "1"
            left = sum_x / divide_num
        if y <= sum_y / divide_num:
            Z_Y += "0"
            top = sum_y / divide_num
        else:
            Z_Y += "1"
            down = sum_y / divide_num
    Z_value = ""

    for i in range(0, len(Z_X) + len(Z_Y)):
        if i % 2 == 0:
            Z_value += Z_X[int(i / 2)]
        else:
            Z_value += Z_X[int((i - 1) / 2)]

    Z_value = int(Z_value, 2)
    Z_value = helper(Z_value, 5)
    print('z base 5 is ', Z_value)
    return Z_value


def z_in_points(n, left, down, right, top):
    dict = {}
    for i in range(0, len(data)):
        z = get_z_value(data[i], n, left, down, right, top)
        dict[str(data[i])] = z
    return dict


if __name__ == '__main__':
    my_list = MBR()
    left = preprocess(my_list[0])
    down = preprocess(my_list[1])
    right = preprocess(my_list[2])
    top = preprocess(my_list[3])

    print("Task 2(1) answer is: ")
    dict = z_in_points(9, left, down, right, top)
    print(len(dict))

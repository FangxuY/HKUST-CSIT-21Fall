import csv
import math
import json
from decimal import Decimal
from re import I

with open('AllPOI.csv', newline='', encoding='utf-8-sig') as f:
    reader = csv.reader(f)
    data = list(reader)


class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Decimal):
            return str(o)
        return super(DecimalEncoder, self).default(o)


def preprocess(num):
    # times 100000
    num = num * 100000
    return fix(float(num))


def fix(num):
    return Decimal(str(num)).quantize(Decimal('0.0000000000000'))


def MBR():
    min_X = Decimal('inf')
    min_Y = Decimal('inf')
    max_X = Decimal('-inf')
    max_Y = Decimal('-inf')
    for i in range(0, len(data)):
        x = Decimal(data[i][0])
        y = Decimal(data[i][1])
        min_X = min(x, min_X)
        min_Y = min(y, min_Y)
        max_Y = max(y, max_Y)
        max_X = max(x, max_X)
    print("Task 1(1) answer is: ")
    print('     min x is ', min_X)
    print('     min y is ', min_Y)
    print('     max x is ', max_X)
    print('     max y is ', max_Y)
    return [fix(min_X), fix(min_Y), fix(max_X), fix(max_Y)]


def position(point, n, min_X, min_Y, max_X, max_Y):
    # times 100000
    x = fix(Decimal(point[0]) * Decimal(100000))
    y = fix(Decimal(point[1]) * Decimal(100000))
    min_X = fix(min_X)
    min_Y = fix(min_Y)
    max_X = fix(max_X)
    max_Y = fix(max_Y)
    divide_num = Decimal(2.0)
    for i in range(0, n):
        sum_x = max_X + min_X
        sum_y = max_Y + min_Y
        if x <= sum_x / divide_num:
            max_X = sum_x / divide_num
        else:
            min_X = sum_x / divide_num
        if y <= sum_y / divide_num:
            max_Y = sum_y / divide_num
        else:
            min_Y = sum_y / divide_num
    dict = {'min_X': fix(min_X), 'min_Y': fix(min_Y), 'max_X': fix(max_X), 'max_Y': fix(max_Y)}
    return json.dumps(dict, cls=DecimalEncoder)


# return true if n is correct
def findN(n, min_X, min_Y, max_X, max_Y):
    ans = 0
    factor = int(math.pow(2, n))
    unitX = (max_X - min_X) / factor
    unitY = (max_Y - min_Y) / factor
    ans_dict = {}
    for i in range (0, factor):
        for j in range (0, factor):
            Min_X = fix(min_X + i * unitX)
            Min_Y = fix(min_Y + j * unitY)
            Max_X = fix(min_X + (i + 1) * unitX)
            Max_Y = fix(min_Y + (j + 1) * unitY)
            # dict = [Min_X, Min_Y, Max_X, Max_Y]
            dict = {'min_X': Min_X, 'min_Y': Min_Y, 'max_X': Max_X, 'max_Y': Max_Y}
            dict_str = json.dumps(dict, cls=DecimalEncoder)
            ans_dict[dict_str] = 0
    for k in range (0, len(data)):
        pos = position(data[k], n, min_X, min_Y, max_X, max_Y)
        ans_dict[pos] += 1

    for key in ans_dict:
        if ans_dict[key] > 128:
            return False
        elif ans_dict[key] <= 5:
            ans += 1
    print("Task 1(2) answer is: ", n)
    print('Task 1(3) answer is: ', ans)
    return True


if __name__ == '__main__':
    my_list = MBR()
    min_X = preprocess(my_list[0])
    min_Y = preprocess(my_list[1])
    max_X = preprocess(my_list[2])
    max_Y = preprocess(my_list[3])
    index = 0
    for i in range(0, 20):
        print(i)
        if findN(i, min_X, min_Y, max_X, max_Y) == True:
            index = i
            break
    # findN(9, min_X, min_Y, max_X, max_Y)


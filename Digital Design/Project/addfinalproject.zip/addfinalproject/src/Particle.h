#ifndef PARTICLE_H
#define PARTICLE_H

#include <stdio.h>
#include <vector>
#include <vecmath.h>
#include <iostream>

using namespace std;

class Particle {
public:
    Particle();
    Vector3f pos;
    float xpos;
    float ypos;
    float zpos;
    bool alive;
    float life;
    float fade;
    Vector3f color;
    float velocity;
    float gravity;
};

#endif

- Assignment4.pdf: Assignment Description

- a4.zip: Starter Code
 - linux/mac/windows sample executable: sample executables for different OS
 - distrib: tested in Windows (MSVS2019), Mac, Ubuntu
 - a4_xcode.zip: alternative for MacOS users

- a4 (>distrib) > sample executables (i.e., a4soln)
 - a4soln: please try the example solution executable

*********************************************************
Q&A:

Executable Errors:

- Run executable error: "command not found" (Linux, Mac):
  Please make a4soln or a4 a command in terminal: "chmod +x ./a4soln" or "chmod 755 ./a4soln"
  Or change file "Properties" (right click) > "Permissions"> enable "Allowing executing file as program".

- Error "Permissin denied":
  Please run file as administrator or root user.

- (Mac) Error "can't be open because it is from an unidentified developer":
  Right click -> open.
  Now you can try run the executable in terminal.

****************************************************

    1.  Unzip submission and extract all files to designated directory
    2.  In terminal, cd to /distrib
    3.  command make
    4.  command sh test_cases.sh. This should produce the images generated from this assignment ranging from names 6.bmp, 10.bmp, 11.bmp and 12.bmp.


Q1. Did you collaborate with anyone in the class? 
Answer: Nope, I did it by myself.

Q2. Were there any references (books, papers, websites, etc.) that you found particularly helpful for completing your assignment? 
Answer: The lecture notes and slides, stackoverflow.com, www.cplusplus.com

Q3. Are there any known problems with your code?

Answer: No.

Q4. Did you do any extra credit?

Answer: No.

Q5. Got any comments about this assignment that you'd like to share?

Answer: No.
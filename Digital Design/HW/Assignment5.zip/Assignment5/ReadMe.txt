******************************************************************
*Please check "3. Starter Code" in pdf before you get started!!!!
*This is a continuous work of Assignment 4!
*Please back up your a4 code before you merge a5 code to your a4!!!!
*SceneParser::getBackgroundColor(Vector3f dir) now takes the ray direction as an argument. Pleaseupdate your main loop accordingly.
*For Windows users, please in a4 project "Add" -> "Existing Files" from a5

*a5.zip contains new codes and example executable for the assignment 
*a5.zip is tested in MSVS2019, Mac, Linux
******************************************************************
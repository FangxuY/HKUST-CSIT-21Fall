# Cloud Computing

Regarding Computing as a utility. 将计算资源作为一种公共资源

Cloud Computing refers to both the applications delivered as services over the Internet and the hardware and systems software in the datacenters that provide those services. 云计算指的是通过互联网以服务形式提供的应用，以及提供这些服务的数据中心中的硬件和系统软件

### 

